# pits_site_statistics

Pits Site Statistics simply retrieves the google analytics data through google analytics API and based on data recieved it plots graphical view of the data.Before you install this module you need to set an analytic account under Google Analytics and a service account under Google developer console.

Requirements
------------
- cURL Library.
- Typo3 7.6.0 and Above.