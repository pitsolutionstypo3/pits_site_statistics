﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Change Log
----------

- 1.0.0 Initial Alpha version.

- 1.0.1 Stable version with Updated documenation.

- 1.0.2 Stable version with Updated documenation and removed dependency that   caused error.
