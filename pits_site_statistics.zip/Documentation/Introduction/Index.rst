﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


What does it do?
================

Pits Site Statistics simply retrieves the google analytics data through google analytics API and based on data recieved it plots graphical view of the data.Before you install this module you need to set an analytic account under Google Analytics and a service account under Google developer console.

To know more about Google analytics ,activating analytic api and creating service account credentials you can refer following Google documentations and our :ref:`faq`

* https://support.google.com/analytics/answer/1008080?hl=en
* https://developers.google.com/analytics/devguides/reporting/core/v3/quickstart/service-php